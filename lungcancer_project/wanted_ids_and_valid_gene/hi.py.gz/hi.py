import pandas as pd
import pickle
import xenaPython as xena
f=open("/home/psin/Desktop/fall2019/6.047/project/TCGA_GTEX_category.txt", "r")
wanted_ids=[]
ad=[]
squamous=[]
gtex=[]
for line in f:
    if "Lung" in line:
        ids=line.split("\t")[0]
        ids=ids.replace("\n", "")
        ids=ids.replace(" ", "")        
        wanted_ids.append(ids)
        if "Squamous" in line:
            squamous.append(ids)
        elif "Adenocarcinoma" in line:
            ad.append(ids)
        elif "GTEX" in ids:
            gtex.append(ids)
            
f.close()
f=open("/home/psin/Desktop/fall2019/6.047/project/probemap.txt", "r")

valid_genes=[]
flag=False
for line in f:
    if flag:
        valid_genes.append(line.split("\t")[0])
    flag=True
f.close()



pickle.dump({"wanted_ids":wanted_ids,"valid_genes":valid_genes}, open("wanted_id_valid_genes"+str(".p"), "wb"))

hub = "https://toil.xenahubs.net"
dataset = "TCGA-GTEx-TARGET-gene-exp-counts.deseq2-normalized.log2"
samples = wanted_ids
probes = valid_genes

indices=[]

val=20
for i in range(0, 10):
    if i != val-1:
        indices.append((i*len(probes)//val, (i+1)*len(probes)//val))
    else:
        indices.append(((val-1)*len(probes)//val,len(probes)))

for i in indices:
    (start,end)=i
    [position, gene] = xena.dataset_probe_values(hub, dataset, samples, probes[start:end])
    pickle.dump({"gene":gene,"position":position}, open("ans"+str(i)+str(".p"), "wb"))
    print("Done")

